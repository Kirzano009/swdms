<?php 

//family details variables

//name
$name1 = $name2 = $name3 = $name4 = $name5 = $name6 = $name7 = $name8 = $name9 = $name10 = "";

//sex
$sex1 = $sex2 = $sex3 = $sex4 = $sex5 = $sex6 = $sex7 = $sex8 = $sex9 = $sex10 = "";

//civil status
$civil1 = $civil2 = $civil3 = $civil4 = $civil5 = $civil6 = $civil7 = $civil8 = $civil9 = $civil10 = "";

//relationship
$relation1 = $relation2 = $relation3 = $relation4 = $relation5 = $relation6 = $relation7 = $relation8 = $relation9 = $relation10 = "";

//educational attainment
$educ1 = $educ2 = $educ3 = $educ4 = $educ5 = $educ6 = $educ7 = $educ8 = $educ9 = $educ10 = "";

//skills/ocupation
$skill1 = $skill2 = $skill3 = $skill4 = $skill5 = $skill6 = $skill7 = $skill8 = $skill9 = $skill10 = "";

//income
$income1 = $income2 = $income3 = $income4 = $income5 = $income6 = $income7 = $income8 = $income9 = $income10 = "";

//birthdate
$birthdate1 = $birthdate2 = $birthdate3 = $birthdate4 = $birthdate5 = $birthdate6 = $birthdate7 = $birthdate8 = $birthdate9 = $birthdate10 = "";

?>