<?php

$servername = "localhost";
$username = "swdo";
$password = "Canaman2018";
$dbname = "swdo";

$error = "";

$con = new mysqli($servername, $username, $password, $dbname);
date_default_timezone_set("Asia/Manila"); 
?>
