<?php 

//family table inputs

//name
$name1 = $_POST["name1"];
$name2 = $_POST["name2"];
$name3 = $_POST["name3"];
$name4 = $_POST["name4"];
$name5 = $_POST["name5"];
$name6 = $_POST["name6"];
$name7 = $_POST["name7"];
$name8 = $_POST["name8"];
$name9 = $_POST["name9"];
$name10 = $_POST["name10"];

//age
$age1 = $_POST["age1"];
$age2 = $_POST["age2"];
$age3 = $_POST["age3"];
$age4 = $_POST["age4"];
$age5 = $_POST["age5"];
$age6 = $_POST["age6"];
$age7 = $_POST["age7"];
$age8 = $_POST["age8"];
$age9 = $_POST["age9"];
$age10 = $_POST["age10"];

//sex
$sex1 = $_POST["sex1"];
$sex2 = $_POST["sex2"];
$sex3 = $_POST["sex3"];
$sex4 = $_POST["sex4"];
$sex5 = $_POST["sex5"];
$sex6 = $_POST["sex6"];
$sex7 = $_POST["sex7"];
$sex8 = $_POST["sex8"];
$sex9 = $_POST["sex9"];
$sex10 = $_POST["sex10"];

//civil status
$civil1 = $_POST["civil1"];
$civil2 = $_POST["civil2"];
$civil3 = $_POST["civil3"];
$civil4 = $_POST["civil4"];
$civil5 = $_POST["civil5"];
$civil6 = $_POST["civil6"];
$civil7 = $_POST["civil7"];
$civil8 = $_POST["civil8"];
$civil9 = $_POST["civil9"];
$civil10 = $_POST["civil10"];

//relationship
$relation1 = $_POST["relation1"];
$relation2 = $_POST["relation2"];
$relation3 = $_POST["relation3"];
$relation4 = $_POST["relation4"];
$relation5 = $_POST["relation5"];
$relation6 = $_POST["relation6"];
$relation7 = $_POST["relation7"];
$relation8 = $_POST["relation8"];
$relation9 = $_POST["relation9"];
$relation10 = $_POST["relation10"];

//educational attainment
$educ1 = $_POST["educ1"];
$educ2 = $_POST["educ2"];
$educ3 = $_POST["educ3"];
$educ4 = $_POST["educ4"];
$educ5 = $_POST["educ5"];
$educ6 = $_POST["educ6"];
$educ7 = $_POST["educ7"];
$educ8 = $_POST["educ8"];
$educ9 = $_POST["educ9"];
$educ10 = $_POST["educ10"];

//skills/ocupation
$skill1 = $_POST["skill1"];
$skill2 = $_POST["skill2"];
$skill3 = $_POST["skill3"];
$skill4 = $_POST["skill4"];
$skill5 = $_POST["skill5"];
$skill6 = $_POST["skill6"];
$skill7 = $_POST["skill7"];
$skill8 = $_POST["skill8"];
$skill9 = $_POST["skill9"];
$skill10 = $_POST["skill10"];

//birthdate
$birthdate1 = date('Y-m-d', strtotime($_POST["birthdate1"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate2 = date('Y-m-d', strtotime($_POST["birthdate2"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate3 = date('Y-m-d', strtotime($_POST["birthdate3"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate4 = date('Y-m-d', strtotime($_POST["birthdate4"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate5 = date('Y-m-d', strtotime($_POST["birthdate5"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate6 = date('Y-m-d', strtotime($_POST["birthdate6"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate7 = date('Y-m-d', strtotime($_POST["birthdate7"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate8 = date('Y-m-d', strtotime($_POST["birthdate8"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate9 = date('Y-m-d', strtotime($_POST["birthdate9"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];
$birthdate10 = date('Y-m-d', strtotime($_POST["birthdate10"])); // Change the format from m-d-Y to Y-m-d $_POST["birthdate1"];

?>