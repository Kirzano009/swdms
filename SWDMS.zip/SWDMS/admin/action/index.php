<?php 

	header("Location: ../calendar/");

?>