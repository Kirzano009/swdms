<?php 

	header("Location: ../../calendar/");

?>