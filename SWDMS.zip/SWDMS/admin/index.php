<?php 

	header("Location: calendar/");

?>